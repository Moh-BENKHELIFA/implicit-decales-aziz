
#include <immintrin.h>

int main(int argc, const char* argv[])
{
    __m256d arst = _mm256_setzero_pd();
    return 0;
}

