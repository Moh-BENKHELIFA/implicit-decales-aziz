#ifndef PSE_CLT_P_H
#define PSE_CLT_P_H

#include "pse_clt.h"

PSE_CLT_API int pse_clt_dummy;

#endif /* PSE_CLT_P_H */
